import { AppRouteRecord } from '@/types/router';
export const systemRoutes: AppRouteRecord = {
    path: '/system',
    name: 'System',
    component: '/index/index',
    meta: {
        title: 'menus.system.title',
        icon: 'ri:user-3-line',
        roles: ['R_SUPER', 'R_ADMIN']
    },
    children: [
        {
            path: 'user',
            name: 'User',
            component: '/system/user',
            meta: {
                title: 'menus.system.user',
                icon: 'ri:user-line',
                keepAlive: true,
                roles: ['R_SUPER', 'R_ADMIN']
            }
        },
        {
            path: 'role',
            name: 'Role',
            component: '/system/role',
            meta: {
                title: 'menus.system.role',
                icon: 'ri:user-settings-line',
                keepAlive: true,
                roles: ['R_SUPER']
            }
        },
        {
            path: 'user-center',
            name: 'UserCenter',
            component: '/system/user-center',
            meta: {
                title: 'menus.system.userCenter',
                icon: 'ri:user-line',
                isHide: true,
                keepAlive: true,
                isHideTab: true
            }
        }
    ]
};
